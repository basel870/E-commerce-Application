package com.example.e_commerce_application;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecyclerViewActivity extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<Product> product_list;
    ProductAdapter product_adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        rv = findViewById(R.id.rv);
        product_list = new ArrayList<>();

        product_list.add(new Product(R.drawable.product1, "Bitzwolf Mini Tripod Webcam", "1080P Full HD webcam", "US$48.89"));
        product_list.add(new Product(R.drawable.product2, "Bitzwolf Compact Photo Printer", "Wireless Instant Printer", "US$55.89"));
        product_list.add(new Product(R.drawable.product3, "Bitzwolf Pan and Tilt Security Camera", "Indoor 1080P HD Camera", "US$78.89"));
        product_list.add(new Product(R.drawable.product4, "Bitzwolf Compact Digital Camera", "HD Camera with Wide Lens", "US$88.55"));
        product_list.add(new Product(R.drawable.product5, "Bitzwolf USB Webcam", "1080P HD Webcam for Computer", "US$23.67"));
        product_list.add(new Product(R.drawable.product6, "Bitzwolf Smart Wi-Fi Security Camera", "1080P Full HD Wireless Camera", "US$44.89"));

        product_adapter = new ProductAdapter(product_list, this);
        rv.setLayoutManager(new GridLayoutManager(RecyclerViewActivity.this, 2));
        rv.setAdapter(product_adapter);
    }
}