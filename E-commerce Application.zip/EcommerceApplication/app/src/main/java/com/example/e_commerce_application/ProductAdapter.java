package com.example.e_commerce_application;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolderClass> {
    ArrayList<Product> product_list;
    Activity activity;

    public ProductAdapter(ArrayList<Product> product_list, Activity activity) {
        this.product_list = new ArrayList<>(product_list);
        this.activity = activity;
    }

    @NonNull
    @Override
    public ProductAdapter.ViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_design, parent, false);
        return new ViewHolderClass(viewItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAdapter.ViewHolderClass holder, int position) {
        holder.product_image.setImageResource(product_list.get(position).get_image());
        holder.product_name.setText(product_list.get(position).get_name());
        holder.product_info.setText(product_list.get(position).get_info());
        holder.product_price.setText(product_list.get(position).get_price());
    }

    @Override
    public int getItemCount() {
        return product_list.size();
    }

    public class ViewHolderClass extends RecyclerView.ViewHolder {
        public ImageView product_image;
        public TextView product_name, product_info, product_price;
        public ViewHolderClass(@NonNull View view) {
            super(view);
            product_image = itemView.findViewById(R.id.product_image);
            product_name = itemView.findViewById(R.id.product_name);
            product_info = itemView.findViewById(R.id.product_info);
            product_price = itemView.findViewById(R.id.product_price);
        }
    }
}