package com.example.e_commerce_application;

public class Product {
    private int image;
    private String name;
    private String info;
    private String price;

    public Product(int image, String name, String info, String price) {
        this.image = image;
        this.name = name;
        this.info = info;
        this.price = price;
    }

    public int get_image() {
        return image;
    }

    public String get_name() {
        return name;
    }

    public String get_info() {
        return info;
    }

    public String get_price() {
        return price;
    }
}